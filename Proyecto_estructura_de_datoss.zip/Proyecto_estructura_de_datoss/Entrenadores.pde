
class Entrenador {
  String nombre, cedula, especialidad, telefono, disponibilidad;
  int entrenamientosRealizados;

  Entrenador(String nombre, String cedula, String especialidad, String telefono, int entrenamientosRealizados, String disponibilidad) {
    this.nombre = nombre;
    this.cedula = cedula;
    this.especialidad = especialidad;
    this.telefono = telefono;
    this.entrenamientosRealizados = entrenamientosRealizados;
    this.disponibilidad = disponibilidad;
  }

  @Override
  public String toString() {
    return nombre + "|" + cedula + "|" + especialidad + "|" + telefono + "|" + entrenamientosRealizados + "|" + disponibilidad;
  }
}

void cargarEntrenadores() {
  String[] lineas = loadStrings("entrenadores.txt");
  if (lineas != null) {
    for (String linea : lineas) {
      String[] datos = linea.split(Pattern.quote("|"));
      if (datos.length == 6) {
        entrenadores.add(new Entrenador(datos[0], datos[1], datos[2], datos[3], Integer.parseInt(datos[4]), datos[5]));
      }
    }
  }
}

void agregarEntrenadorInteractivo() {
  String nombre = JOptionPane.showInputDialog("Ingrese el nombre del entrenador:");
  String cedula = JOptionPane.showInputDialog("Ingrese la cédula del entrenador:");
  String especialidad = JOptionPane.showInputDialog("Ingrese la especialidad:");
  String telefono = JOptionPane.showInputDialog("Ingrese el teléfono:");
  String disponibilidad = JOptionPane.showInputDialog("Ingrese la disponibilidad:");

  entrenadores.add(new Entrenador(nombre, cedula, especialidad, telefono, 0, disponibilidad));
}

void guardarEntrenadores() {
  PrintWriter salida = createWriter("data/entrenadores.txt");
  for (Entrenador e : entrenadores) {
    salida.println(e.toString());
  }
  salida.close();
}
