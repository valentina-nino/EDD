import java.io.*;
import java.util.*;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

ArrayList<Entrenador> entrenadores = new ArrayList<>();
ArrayList<Deportista> deportistas = new ArrayList<>();
ArrayList<Sesion> sesiones = new ArrayList<>();

void setup() {
  size(800, 600);
  cargarEntrenadores();
  //cargarDeportistas();
  cargarSesiones();
  
  while (true) {
    String opcion = JOptionPane.showInputDialog(
      "Seleccione una opción:\n1. Agregar Entrenador\n2. Agregar Deportista\n3. Gestionar Sesiones\n4. Salir"
    );

    if (opcion == null || opcion.equals("4")) {
      break; // Sale del programa si elige "4" o cancela.
    } else if (opcion.equals("1")) {
      agregarEntrenadorInteractivo();
      guardarEntrenadores();
    } else if (opcion.equals("2")) {
      agregarDeportistaInteractivo();
      guardarDeportistas();
    } else if (opcion.equals("3")) {
      gestionarSesiones();
    } else {
      JOptionPane.showMessageDialog(null, "Opción no válida, intente de nuevo.");
    }
  }
}
