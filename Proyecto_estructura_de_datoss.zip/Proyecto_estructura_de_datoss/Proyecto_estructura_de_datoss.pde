class Deportista {
  String nombre, cedula, deporte;
  int sesionesRealizadas;

  Deportista(String nombre, String cedula, String deporte, int sesionesRealizadas) {
    this.nombre = nombre;
    this.cedula = cedula;
    this.deporte = deporte;
    this.sesionesRealizadas = sesionesRealizadas;
  }

  @Override
  public String toString() {
    return nombre + "|" + cedula + "|" + deporte + "|" + sesionesRealizadas;
  }
}

/*void cargarDeportistas() {
  String[] lineas = loadStrings("deportistas.txt");
  if (lineas != null) {
    for (String linea : lineas) {
      String[] datos = linea.split(Pattern.quote("|"));
      if (datos.length == 4) {
        deportistas.add(new Deportista(datos[0], datos[1], datos[2], Integer.parseInt(datos[3])));
      }
    }
  }
}*/

void agregarDeportistaInteractivo() {
  String nombre = JOptionPane.showInputDialog("Ingrese el nombre del deportista:");
  String cedula = JOptionPane.showInputDialog("Ingrese la cédula:");
  String deporte = JOptionPane.showInputDialog("Ingrese deporte o lesion fisica:");

  deportistas.add(new Deportista(nombre, cedula, deporte, 0));
}

void guardarDeportistas() {
  PrintWriter salida = createWriter("data/deportistas.txt");
  for (Deportista d : deportistas) {
    salida.println(d.toString());
  }
  salida.close();
}
