class Sesion {
  String codigo;
  String nombreDeportista;
  String cedulaDeportista;
  String especialidad;
  String entrenador;
  String fecha;

  Sesion(String codigo, String nombreDeportista, String cedulaDeportista, String especialidad, String entrenador, String fecha) {
    this.codigo = codigo;
    this.nombreDeportista = nombreDeportista;
    this.cedulaDeportista = cedulaDeportista;
    this.especialidad = especialidad;
    this.entrenador = entrenador;
    this.fecha = fecha;
  }

  @Override
  public String toString() {
    return codigo + "|" + nombreDeportista + "|" + cedulaDeportista + "|" + especialidad + "|" + entrenador + "|" + fecha;
  }
}

void gestionarSesiones() {
  while (true) {
    String opcion = JOptionPane.showInputDialog(
      "Gestión de Sesiones:\n1. Ver Sesiones\n2. Agregar Sesión\n3. Volver al Menú Principal"
    );

    if (opcion == null || opcion.equals("3")) {
      break;
    } else if (opcion.equals("1")) {
      verSesiones();
    } else if (opcion.equals("2")) {
      agregarSesionInteractivo();
      guardarSesiones();
    } else {
      JOptionPane.showMessageDialog(null, "Opción no válida, intente de nuevo.");
    }
  }
}

void verSesiones() {
  if (sesiones.isEmpty()) {
    JOptionPane.showMessageDialog(null, "No hay sesiones registradas.");
    return;
  }

  String mensaje = "Sesiones Registradas:\n";
  for (Sesion s : sesiones) {
    mensaje += "Código: " + s.codigo + "\n"
             + "Deportista: " + s.nombreDeportista + " (" + s.cedulaDeportista + ")\n"
             + "Especialidad: " + s.especialidad + "\n"
             + "Entrenador: " + s.entrenador + "\n"
             + "Fecha: " + s.fecha + "\n\n";
  }
  
  JOptionPane.showMessageDialog(null, mensaje);
}

void guardarSesiones() {
  PrintWriter salida = createWriter("data/sesiones.txt");
  for (Sesion s : sesiones) {
    salida.println(s.toString());
  }
  salida.close();
  println("Sesiones guardadas correctamente.");
}

void agregarSesionInteractivo() {
  if (deportistas.isEmpty() || entrenadores.isEmpty()) {
    JOptionPane.showMessageDialog(null, "Debe haber al menos un deportista y un entrenador registrados.");
    return;
  }

  String codigo = UUID.randomUUID().toString();
  String nombreDeportista = JOptionPane.showInputDialog("Ingrese el nombre del deportista:");
  String cedulaDeportista = JOptionPane.showInputDialog("Ingrese la cédula del deportista:");
  
  String especialidad = JOptionPane.showInputDialog("Ingrese la especialidad de la sesión:");
  String entrenador = JOptionPane.showInputDialog("Ingrese el nombre del entrenador asignado:");
  String fecha = JOptionPane.showInputDialog("Ingrese la fecha de la sesión (dd/mm/aaaa):");

  // Verificar que el deportista y entrenador existen
  boolean deportistaExiste = false;
  boolean entrenadorExiste = false;

  for (Deportista d : deportistas) {
    if (d.cedula.equals(cedulaDeportista)) {
      deportistaExiste = true;
      break;
    }
  }

  for (Entrenador e : entrenadores) {
    if (e.nombre.equals(entrenador)) {
      entrenadorExiste = true;
      break;
    }
  }

  if (!deportistaExiste) {
    JOptionPane.showMessageDialog(null, "El deportista con la cédula ingresada no existe.");
    return;
  }

  if (!entrenadorExiste) {
    JOptionPane.showMessageDialog(null, "El entrenador ingresado no existe.");
    return;
  }

  // Crear y guardar la sesión
  Sesion nuevaSesion = new Sesion(codigo, nombreDeportista, cedulaDeportista, especialidad, entrenador, fecha);
  sesiones.add(nuevaSesion);
  JOptionPane.showMessageDialog(null, "Sesión agregada correctamente.");
}

void cargarSesiones() {
  String[] lineas = loadStrings("data/sesiones.txt"); // Leer archivo de sesiones
  if (lineas != null) {
    for (String linea : lineas) {
      String[] datos = linea.split(Pattern.quote("|")); // Separar los datos por "|"
      if (datos.length == 6) { // Verificar que tenga los 6 campos
        Sesion s = new Sesion(datos[0], datos[1], datos[2], datos[3], datos[4], datos[5]);
        sesiones.add(s); // Agregar la sesión a la lista
      }
    }
  }
  println("Sesiones cargadas correctamente.");
}
